#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  3 09:49:54 2020

@author: enzo
"""
#%%
import pandas as pd


true_df_name = 'matrici_multiwell_df.pkl'
from well_plate_project.config import data_dir
path = data_dir / 'raw' / 'matrix'
df_file = path /  true_df_name
assert df_file.is_file()
true_df = pd.read_pickle(str(df_file))



#TODO dict value


source_folder =  data_dir / 'processed' / 'Experiments'
data_dict_df = {}
for pickle in source_folder.glob('*.pkl'): #TODO pkl
    print(f'Processing {pickle}', end='\n')
    data_df = pd.read_pickle(str(pickle))
    data_dict_df[pickle.stem] =  data_df
    

#%%

columns = ['well_plate_name', 'wp_image_version', 'well_name', 'dict_values']
df_weel_plates = pd.DataFrame(columns=columns)

    
for key_name, dataframe in data_dict_df.items():
    stacked = dataframe.stack().reset_index()
    stacked.insert(loc=0, column='well_name', value=(stacked["level_0"] + stacked["level_1"].astype(str)), allow_duplicates = False)
    stacked = stacked.drop(['level_0'], axis=1)
    stacked = stacked.drop(['level_1'], axis=1)
    name_vect = key_name.split("_")
    stacked.insert(0, 'wp_image_version', name_vect[1])
    stacked.insert(0, 'well_plate_name', name_vect[0].upper())
    stacked = stacked.rename(columns={0: "dict_values"})
    df_weel_plates = df_weel_plates.append(stacked)

#%%
#JUST TEST!
# name = 'l1_20a_df'
# temp_dataframe = data_dict_df[name]
# stacked = temp_dataframe.stack().reset_index()
# # Alternative to get well names
# # row_name=list(map(chr, range(ord('A'), ord('H')+1)))
# # col_name=[str(each) for each in range(1,13)]
# # well_names = [f'{a}{b}' for a in row_name for b in col_name]
# # stacked.insert(loc=0, column='well_name', value=well_names, allow_duplicates = False)
# stacked.insert(loc=0, column='well_name', value=(stacked["level_0"] + stacked["level_1"].astype(str)), allow_duplicates = False)
# stacked = stacked.drop(['level_0'], axis=1)
# stacked = stacked.drop(['level_1'], axis=1)
# name_vect = name.split("_")
# stacked.insert(0, 'wp_image_version', name_vect[1])
# stacked.insert(0, 'well_plate_name', name_vect[0].upper())
# stacked = stacked.rename(columns={0: "dict_values"})


#%%

def  reform(elmnts):
    result = {'_'.join([l0_key, l1_key, l2_key]): values for l0_key, l0_dict in elmnts.items() for l1_key, l1_dict in l0_dict.items() for l2_key, values in l1_dict.items() }
    return result
reformed = df_weel_plates['dict_values'].apply(lambda d: pd.Series(reform(d)))
result = pd.concat([df_weel_plates, reformed], axis=1, sort=False)


#%%

ml_df = pd.merge(true_df,result,on=['well_plate_name', 'well_name' ])
print("Done")


#%% Machine learning


from sklearn.preprocessing import StandardScaler

non_features=['well_plate_name', 'well_name', 'class_target', 'value_target', 'wp_image_version', 'dict_values']
features = ml_df.columns.difference(non_features)


#clan features
#features_red = [col for col in features if not col.endswith('mean')]
#features_red = [col for col in features_red if not col.endswith('skewness')]
#features = features_red


# Separating out the features
x = ml_df.loc[:, features].values
# Separating out the target
y_real = ml_df.loc[:,['value_target']].values
y_class= ml_df.loc[:,['class_target']].values
y_real_class = ml_df.loc[:,['value_target','class_target']].values
# Standardizing the features
x = StandardScaler().fit_transform(x)


targets = ml_df['class_target'].unique()

#%% Predict


#TODO linear, tanto per  (non ha senso su molte features)
#SVM
#MLP

#TODO random forest regressor + MAPE, RMSE

#%% Linear


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split( x, y_real_class, test_size=0.25, random_state=42)

import numpy as np
from sklearn.linear_model import LinearRegression
model = LinearRegression().fit(X_train, y_train[:,0])

y_pred = model.predict(X_test)


from sklearn import metrics
print("LinearRegression:")
print('Mean Absolute Error:', metrics.mean_absolute_error(y_test[:,0], y_pred))
print('Mean Squared Error:', metrics.mean_squared_error(y_test[:,0], y_pred))
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test[:,0], y_pred)))

df_linear_regressor = pd.DataFrame({'Actual': y_test[:,0],'Actual_class': y_test[:,1], 'Predicted': y_pred,'DiffPerc': np.abs(y_test[:,0]-y_pred)/y_pred, 'DiffAbs': np.abs(y_test[:,0]-y_pred) })
df_linear_regressor

#%% SVM

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split( x, y_class.ravel(), test_size=0.20, random_state=42)



#Import svm model
from sklearn import svm


#We’ll create two objects from SVM, to create two different classifiers; one with Polynomial kernel, and another one with RBF kernel:
#Train the model using the training sets
rbf = svm.SVC(kernel='rbf', gamma=0.5, C=0.1).fit(X_train, y_train)
poly = svm.SVC(kernel='poly', degree=3, C=1).fit(X_train, y_train)


#To calculate the efficiency of the two models, we’ll test the two classifiers using the test data set:
poly_pred = poly.predict(X_test)
rbf_pred = rbf.predict(X_test)

from sklearn.metrics import accuracy_score, f1_score
#Finally, we’ll calculate the accuracy and f1 scores for SVM with Polynomial kernel:
poly_accuracy = accuracy_score(y_test, poly_pred)
poly_f1 = f1_score(y_test, poly_pred, average='weighted')
print('Accuracy (Polynomial Kernel): ', "%.2f" % (poly_accuracy*100))
print('F1 (Polynomial Kernel): ', "%.2f" % (poly_f1*100))

#In the same way, the accuracy and f1 scores for SVM with RBF kernel:
rbf_accuracy = accuracy_score(y_test, rbf_pred)
rbf_f1 = f1_score(y_test, rbf_pred, average='weighted')
print('Accuracy (RBF Kernel): ', "%.2f" % (rbf_accuracy*100))
print('F1 (RBF Kernel): ', "%.2f" % (rbf_f1*100))


from sklearn.metrics import classification_report
print("SVC-PolynomialKernel")
print(classification_report(y_test, poly_pred, target_names=targets))
print("SVC-RBF")
print(classification_report(y_test, rbf_pred, target_names=targets))


#%% Predict mlp


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split( x, y_class.ravel(), test_size=0.20, random_state=42)

from sklearn.neural_network import MLPClassifier
clf = MLPClassifier(hidden_layer_sizes=(256,128,64,32),activation="relu",random_state=1).fit(X_train, y_train)
y_pred=clf.predict(X_test)

print("MLPClassifier")
print(classification_report(y_test, y_pred, target_names=targets))
from sklearn.metrics import plot_confusion_matrix
import matplotlib.pyplot as plt
fig=plot_confusion_matrix(clf, X_test, y_test,display_labels=targets)
fig.figure_.suptitle("Confusion Matrix ")
plt.show()







#%% Predict

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split( x, y_class.ravel(), test_size=0.25, random_state=42)


from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification
clf = RandomForestClassifier(n_estimators=50)
clf.fit(X_train, y_train)


y_pred = clf.predict(X_test)


from sklearn.metrics import classification_report
print("RandomForestClassifier")
print(classification_report(y_test, y_pred, target_names=targets))


feat = pd.Series(clf.feature_importances_, index = features)

plt.figure(figsize=(10,30))
feat.sort_values().plot(kind='barh')

import xgboost as XGB
xgb = XGB.XGBClassifier()
xgb.fit(X_train, y_train)
y_pred = xgb.predict(X_test)

print("xgboost")
print(classification_report(y_test, y_pred, target_names=targets))

feat = pd.Series(xgb.feature_importances_, index = features)

plt.figure(figsize=(10,30))
feat.sort_values().plot(kind='barh')
plt.show()

#print(classification_report(y_true, y_pred, target_names=target_names))
